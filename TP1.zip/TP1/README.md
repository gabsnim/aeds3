Trabalho prático - Algoritmos e Estruturas de Dados III






Integrantes:

Enzo
Gabriel Xavier
Pedro Tinoco
Vitor de Meira

Questionário:

- Sim
As operações de inclusão, busca, alteração e exclusão de séries estão implementadas e funcionando corretamente?
- Sim
As operações de inclusão, busca, alteração e exclusão de episódios, por série, estão implementadas e funcionando corretamente?
- Sim
Essas operações usam a classe CRUD genérica para a construção do arquivo e as classes Tabela Hash Extensível e Árvore B+ como índices diretos e indiretos? 
- Sim
O atributo de ID de série, como chave estrangeira, foi criado na classe de episódios?
- Sim
Há uma árvore B+ que registre o relacionamento 1:N entre episódios e séries?
- Sim
Há uma visualização das séries que mostre os episódios por temporada?
- Não
A remoção de séries checa se há algum episódio vinculado a ela?
- Não
A inclusão da série em um episódio se limita às séries existentes?
- Não
O trabalho está funcionando corretamente?
- Sim/Não, Funcionando corretamente infere TODAS as especificações implementadas e funcionando, não é o caso aqui.
O trabalho está completo?
- Sim
O trabalho é original e não a cópia de um trabalho de outro grupo?
- Sim